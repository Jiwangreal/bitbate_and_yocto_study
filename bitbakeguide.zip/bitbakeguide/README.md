Samples for the BitBake tutorial at
http://a4z.gitlab.io/docs/BitBake/guide.html

you can clone this git repository or look at the source here: https://bitbucket.org/a4z/bitbakeguide/src